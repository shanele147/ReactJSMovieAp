import React from 'react'

const MovieDetail = () => {
    return (
        <div>MovieDetail</div>
    )
}

export default MovieDetail