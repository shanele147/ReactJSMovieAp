import React, { useRef, useState } from "react";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/pagination";
import "swiper/css/navigation";

import "./SwiperSlider.css";
// import required modules
import { FreeMode, Pagination, Navigation } from "swiper";
import { API_KEY, image_url } from "../../constant/const-key";

function CategorySwiper(props) {
  const { movieList } = props;
  movieList && console.log(movieList);
  const filerMovies =
    movieList && movieList.filter((movie) => movie.vote_average > 7);
  const movies = filerMovies.map((movie, index) => {
    const { title, id, poster_path, release_date } = movie;
    return (
      <>
        <SwiperSlide key={index}>
          <img
            src={`${image_url}${poster_path}?api_key=${API_KEY}&language=en-US)`}
          ></img>
        </SwiperSlide>
      </>
    );
  });
  return (
    <div className="container category-swiper">
      <div className="row">
        <div className="col-12">
          <Swiper
            navigation={true}
            slidesPerView={4}
            spaceBetween={30}
            freeMode={true}
            pagination={{
              clickable: true,
            }}
            modules={[FreeMode, Pagination, Navigation]}
            className="mySwiper"
          >
            {movies}
            {/* <SwiperSlide>Slide 1</SwiperSlide>
            <SwiperSlide>Slide 2</SwiperSlide>
            <SwiperSlide>Slide 3</SwiperSlide>
            <SwiperSlide>Slide 4</SwiperSlide>
            <SwiperSlide>Slide 5</SwiperSlide>
            <SwiperSlide>Slide 6</SwiperSlide>
            <SwiperSlide>Slide 7</SwiperSlide>
            <SwiperSlide>Slide 8</SwiperSlide>
            <SwiperSlide>Slide 9</SwiperSlide> */}
          </Swiper>
        </div>
      </div>
    </div>
  );
}

export default CategorySwiper;
